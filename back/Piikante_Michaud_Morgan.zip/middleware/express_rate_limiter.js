/**
* Ce fichier fait partie du projet piikante.
*
* Configuration de express rate limit pour éviter une attaque bruteforce du login.
*
* 
* @copyright 2022 Morgussian
*/

const rateLimit = require('express-rate-limit');


exports.limiterConfig = 
	rateLimit({
	windowMs: 15 * 60 * 1000, // 15 minutes
	max: 100, // Limit each IP to 100 requests per `window` (here, per 15 minutes)
	standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers
	})


